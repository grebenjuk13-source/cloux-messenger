#!/usr/bin/env bash
set -euo pipefail
python3 server.py &
api_pid=$!
cleanup() {
  kill "$api_pid" 2>/dev/null || true
  wait "$api_pid" 2>/dev/null || true
}
trap cleanup EXIT INT TERM
npm run dev:ui
