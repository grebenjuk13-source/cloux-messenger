export type User = { id: string; handle: string; createdAt: number };
export type Reaction = { emoji: string; count: number; mine: boolean };
export type Message = { id: string; clientId: string; authorId: string; author: string; text: string; createdAt: number; editedAt: number | null; replyTo: { id: string; author: string; text: string } | null; reactions: Reaction[]; pending?: boolean };
export type Chat = { id: string; kind: 'notes' | 'dm'; title: string; peerId?: string; lastAt: number; wallpaper: string };
export type Session = { user: User; chats: Chat[]; selected: string; messages: Message[]; prefs: { preset: string; wallpaper: string; reducedMotion: boolean } };
