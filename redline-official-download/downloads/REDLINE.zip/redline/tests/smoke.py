#!/usr/bin/env python3
"""Dependency-free smoke checks for the account and message vertical slice."""
import http.cookiejar, json, os, socket, subprocess, sys, tempfile, time, urllib.error, urllib.request, uuid
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def client():
    jar=http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar))
def call(op, base, path, data=None):
    request=urllib.request.Request(base+path, data=None if data is None else json.dumps(data).encode(), headers={'Content-Type':'application/json'})
    try:
        with op.open(request) as response:
            raw=response.read(); payload=json.loads(raw) if 'application/json' in response.headers.get('Content-Type','') else raw
            return response.status,payload,response.headers
    except urllib.error.HTTPError as err:
        return err.code,json.loads(err.read()),err.headers

with tempfile.TemporaryDirectory(prefix='redline-test-') as tmp:
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
    env=os.environ|{'REDLINE_DB':str(Path(tmp)/'redline.sqlite3'),'REDLINE_HOST':'127.0.0.1','PORT':str(port)}
    process=subprocess.Popen([sys.executable,str(ROOT/'server.py')],cwd=ROOT,env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    base=f'http://127.0.0.1:{port}'
    try:
        for _ in range(60):
            try:
                urllib.request.urlopen(base+'/api/health',timeout=.3).close();break
            except Exception:time.sleep(.1)
        else:raise RuntimeError('API did not start')
        status,html,headers=call(client(),base,'/')
        assert status==200 and b'REDLINE' in html and headers.get('Content-Security-Policy')
        alice='alice'+uuid.uuid4().hex[:6];bob='bob'+uuid.uuid4().hex[:6]
        a,b=client(),client()
        assert call(a,base,'/api/register',{'handle':'Кирилиця','password':'StrongPass123'})[0]==400
        assert call(a,base,'/api/register',{'handle':'red_line','password':'StrongPass123'})[0]==400
        status,created,_=call(a,base,'/api/register',{'handle':alice,'password':'StrongPass123'})
        assert status==201 and len(created['chats'])==1 and created['chats'][0]['title']=='NOTES'
        assert call(b,base,'/api/register',{'handle':alice.upper(),'password':'StrongPass123'})[0]==409
        assert call(b,base,'/api/register',{'handle':bob,'password':'OtherPass123'})[0]==201
        assert call(a,base,'/api/callsign?q='+alice)[1]['available'] is False
        person=call(a,base,'/api/people?q='+bob[:4])[1]['people'][0]
        chat=call(a,base,'/api/chats',{'userId':person['id']})[1]['id']
        assert call(a,base,'/api/chats',{'userId':person['id']})[1]['id']==chat
        item={'clientId':str(uuid.uuid4()),'text':'persistent message'}
        first=call(a,base,f'/api/chats/{chat}/messages',item)[1]['message']
        retry=call(a,base,f'/api/chats/{chat}/messages',item)[1]['message']
        assert first['id']==retry['id']
        message=first['id']
        assert call(a,base,f'/api/messages/{message}/reaction',{'emoji':'🔥'})[1]['message']['reactions'][0]['count']==1
        assert call(b,base,f'/api/chats/{chat}/messages')[1]['messages'][0]['reactions'][0]['count']==1
        assert call(a,base,f'/api/messages/{message}/edit',{'text':'edited'})[1]['message']['editedAt']
        call(a,base,f'/api/chats/{chat}/draft',{'text':'saved draft'})
        call(a,base,'/api/prefs',{'preset':'PHOSPHOR','wallpaper':'geometry','reducedMotion':True})
        call(a,base,'/api/logout',{})
        fresh=client();assert call(fresh,base,'/api/login',{'identifier':alice,'password':'StrongPass123'})[0]==200
        session=call(fresh,base,'/api/session')[1]
        assert any(row['kind']=='notes' for row in session['chats']) and session['prefs']['preset']=='PHOSPHOR'
        assert call(fresh,base,f'/api/chats/{chat}/draft')[1]['text']=='saved draft'
        assert call(fresh,base,'/api/register',[])[0]==400
        assert call(fresh,base,f'/api/messages/{message}/delete',{})[0]==200
        assert call(b,base,f'/api/chats/{chat}/messages')[1]['messages']==[]
        print('PASS: account isolation, callsign validation, NOTES, unique DM, duplicate-send guard, shared reactions, edit/delete, drafts, preferences, fresh login, malformed body')
    finally:
        process.terminate()
        try:process.wait(timeout=3)
        except subprocess.TimeoutExpired:process.kill()
