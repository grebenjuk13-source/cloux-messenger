#!/usr/bin/env python3
"""Small single-instance REDLINE server. Data is stored in redline/data/redline.sqlite3."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
import hashlib, hmac, json, mimetypes, os, re, secrets, sqlite3, time

ROOT = Path(__file__).parent.resolve()
DB = Path(os.environ.get('REDLINE_DB', ROOT / 'data' / 'redline.sqlite3'))
DB.parent.mkdir(parents=True, exist_ok=True)
RESERVED = {'admin','support','redline','system','notes','help','security','staff'}
HANDLE = re.compile(r'^[A-Za-z][A-Za-z0-9_]{2,20}$')
RATE_BUCKETS = {}

def db():
    con = sqlite3.connect(DB, timeout=15)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA journal_mode=WAL')
    return con

with db() as c:
    c.executescript('''
      CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, handle TEXT COLLATE NOCASE UNIQUE, salt BLOB NOT NULL, password_hash BLOB NOT NULL, created INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, expires INTEGER NOT NULL);
      CREATE TABLE IF NOT EXISTS chats(id TEXT PRIMARY KEY, kind TEXT NOT NULL, pair_key TEXT UNIQUE, created INTEGER NOT NULL, wallpaper TEXT NOT NULL DEFAULT 'carbon');
      CREATE TABLE IF NOT EXISTS members(chat_id TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, PRIMARY KEY(chat_id,user_id));
      CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, chat_id TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE, client_id TEXT NOT NULL, author_id TEXT NOT NULL REFERENCES users(id), text TEXT NOT NULL, created INTEGER NOT NULL, edited INTEGER, reply_id TEXT REFERENCES messages(id) ON DELETE SET NULL, UNIQUE(chat_id,client_id));
      CREATE INDEX IF NOT EXISTS message_feed ON messages(chat_id,created DESC);
      CREATE TABLE IF NOT EXISTS reactions(message_id TEXT NOT NULL REFERENCES messages(id) ON DELETE CASCADE, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, emoji TEXT NOT NULL, PRIMARY KEY(message_id,user_id,emoji));
      CREATE TABLE IF NOT EXISTS prefs(user_id TEXT PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE, preset TEXT NOT NULL DEFAULT 'REDLINE', wallpaper TEXT NOT NULL DEFAULT 'carbon', reduced INTEGER NOT NULL DEFAULT 0);
      CREATE TABLE IF NOT EXISTS drafts(user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE, chat_id TEXT NOT NULL REFERENCES chats(id) ON DELETE CASCADE, text TEXT NOT NULL, changed INTEGER NOT NULL, PRIMARY KEY(user_id,chat_id));
    ''')

def password_hash(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    return salt, hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)

def now(): return int(time.time() * 1000)

class Handler(BaseHTTPRequestHandler):
    server_version = 'REDLINE/0.1'
    def log_message(self, fmt, *args): pass
    def send_json(self, data, status=200, headers=None):
        body = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(status); self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Referrer-Policy','strict-origin-when-cross-origin'); self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"); self.send_header('Content-Length',str(len(body)))
        for k,v in (headers or {}).items(): self.send_header(k,v)
        self.end_headers(); self.wfile.write(body)
    def session_cookie(self, token, max_age):
        secure='; Secure' if self.headers.get('X-Forwarded-Proto','').lower()=='https' else ''
        return f'rl_session={token}; Path=/; HttpOnly; SameSite=Strict; Max-Age={max_age}{secure}'
    def rate_limited(self, scope, max_count, period):
        stamp=time.time(); key=(self.client_address[0],scope)
        bucket=[t for t in RATE_BUCKETS.get(key,[]) if stamp-t<period]
        if len(bucket)>=max_count:RATE_BUCKETS[key]=bucket;return True
        bucket.append(stamp);RATE_BUCKETS[key]=bucket
        return False
    def body(self):
        length = int(self.headers.get('Content-Length','0'))
        if length > 128_000: raise ValueError('Запит завеликий.')
        value=json.loads(self.rfile.read(length) or b'{}')
        if not isinstance(value,dict):raise ValueError('Тіло запиту має бути JSON-об’єктом.')
        return value
    def route(self): return urlparse(self.path).path
    def auth(self):
        raw = self.headers.get('Cookie','')
        token = next((x.split('=',1)[1] for x in raw.split('; ') if x.startswith('rl_session=')), None)
        if not token: return None
        with db() as c:
            row = c.execute('SELECT u.id,u.handle,s.token_hash FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires>?',(hashlib.sha256(token.encode()).hexdigest(),now())).fetchone()
            return (dict(row), token) if row else None
    def need(self):
        a=self.auth()
        if not a: self.send_json({'error':'Сесія завершилась. Увійди ще раз.'},401); return None
        return a
    def do_GET(self):
        p=self.route()
        if p == '/api/health': return self.send_json({'ok':True,'storage':'sqlite-single-instance','database':str(DB)})
        if p == '/api/callsign':
            handle=parse_qs(urlparse(self.path).query).get('q',[''])[0]
            if not HANDLE.fullmatch(handle):return self.send_json({'valid':False,'available':False,'reason':'format'})
            compact=handle.lower().replace('_','')
            if any(compact.startswith(name.replace('_','')) for name in RESERVED):return self.send_json({'valid':True,'available':False,'reason':'reserved'})
            with db() as c:
                exists=c.execute('SELECT 1 FROM users WHERE handle=? COLLATE NOCASE',(handle,)).fetchone()
                return self.send_json({'valid':True,'available':not bool(exists),'reason':'taken' if exists else 'free'})
        if p.startswith('/api/'):
            a=self.need()
            if not a: return
            uid=a[0]['id']
            if p == '/api/session':
                with db() as c:
                    prefs=c.execute('SELECT preset,wallpaper,reduced FROM prefs WHERE user_id=?',(uid,)).fetchone()
                    rows=c.execute('''SELECT ch.id,ch.kind,ch.created,ch.wallpaper, m.user_id peer_id, u.handle peer_handle, COALESCE((SELECT created FROM messages WHERE chat_id=ch.id ORDER BY created DESC LIMIT 1),ch.created) last_at FROM chats ch JOIN members mine ON mine.chat_id=ch.id AND mine.user_id=? LEFT JOIN members m ON m.chat_id=ch.id AND m.user_id<>? LEFT JOIN users u ON u.id=m.user_id ORDER BY CASE ch.kind WHEN 'notes' THEN 0 ELSE 1 END,last_at DESC''',(uid,uid)).fetchall()
                    chats=[{'id':r['id'],'kind':r['kind'],'title':'NOTES' if r['kind']=='notes' else r['peer_handle'],'peerId':r['peer_id'],'lastAt':r['last_at'],'wallpaper':r['wallpaper']} for r in rows]
                    return self.send_json({'user':{'id':uid,'handle':a[0]['handle']},'chats':chats,'selected':chats[0]['id'] if chats else '', 'prefs':{'preset':prefs['preset'],'wallpaper':prefs['wallpaper'],'reducedMotion':bool(prefs['reduced'])}})
            if p == '/api/people':
                q=parse_qs(urlparse(self.path).query).get('q',[''])[0]
                if not q or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]{0,20}',q): return self.send_json({'people':[]})
                with db() as c:
                    rows=c.execute('SELECT id,handle FROM users WHERE id<>? AND handle LIKE ? ESCAPE \'\\\' COLLATE NOCASE ORDER BY handle LIMIT 10',(uid,q.replace('%','\\%').replace('_','\\_')+'%',)).fetchall()
                    return self.send_json({'people':[dict(r) for r in rows]})
            m=re.fullmatch(r'/api/chats/([\w-]+)/messages',p)
            if m:
                chat=m.group(1); before=parse_qs(urlparse(self.path).query).get('before',[str(2**63-1)])[0]
                with db() as c:
                    if not c.execute('SELECT 1 FROM members WHERE chat_id=? AND user_id=?',(chat,uid)).fetchone(): return self.send_json({'error':'Чат недоступний.'},404)
                    rows=c.execute('SELECT * FROM messages WHERE chat_id=? AND created<? ORDER BY created DESC LIMIT 60',(chat,int(before))).fetchall()
                    return self.send_json({'messages':[self.message(c,r,uid) for r in reversed(rows)]})
            m=re.fullmatch(r'/api/chats/([\w-]+)/draft',p)
            if m:
                with db() as c:
                    if not c.execute('SELECT 1 FROM members WHERE chat_id=? AND user_id=?',(m.group(1),uid)).fetchone():return self.send_json({'error':'Чат недоступний.'},404)
                    r=c.execute('SELECT text FROM drafts WHERE user_id=? AND chat_id=?',(uid,m.group(1))).fetchone();return self.send_json({'text':r['text'] if r else ''})
            m=re.fullmatch(r'/api/chats/([\w-]+)/wallpaper',p)
            if m:
                with db() as c:
                    r=c.execute('SELECT wallpaper FROM chats WHERE id=?',(m.group(1),)).fetchone()
                    if not r or not c.execute('SELECT 1 FROM members WHERE chat_id=? AND user_id=?',(m.group(1),uid)).fetchone():return self.send_json({'error':'Чат недоступний.'},404)
                    return self.send_json({'wallpaper':r['wallpaper']})
            return self.send_json({'error':'Не знайдено.'},404)
        # Static production client
        path=(ROOT/'dist'/p.lstrip('/')).resolve()
        if path.is_dir(): path=path/'index.html'
        if not str(path).startswith(str(ROOT/'dist')) or not path.exists(): path=ROOT/'dist'/'index.html'
        if not path.exists(): return self.send_error(404)
        data=path.read_bytes(); self.send_response(200); self.send_header('Content-Type',mimetypes.guess_type(str(path))[0] or 'text/html'); self.send_header('X-Content-Type-Options','nosniff'); self.send_header('Referrer-Policy','strict-origin-when-cross-origin'); self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; font-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
    def message(self,c,r,uid):
        author=c.execute('SELECT handle FROM users WHERE id=?',(r['author_id'],)).fetchone()
        reply=None
        if r['reply_id']:
            rr=c.execute('SELECT m.id,m.text,u.handle FROM messages m JOIN users u ON u.id=m.author_id WHERE m.id=?',(r['reply_id'],)).fetchone()
            if rr: reply={'id':rr['id'],'text':rr['text'],'author':rr['handle']}
        react=c.execute('SELECT emoji,COUNT(*) count,SUM(user_id=?) mine FROM reactions WHERE message_id=? GROUP BY emoji',(uid,r['id'])).fetchall()
        return {'id':r['id'],'clientId':r['client_id'],'authorId':r['author_id'],'author':author['handle'],'text':r['text'],'createdAt':r['created'],'editedAt':r['edited'],'replyTo':reply,'reactions':[{'emoji':x['emoji'],'count':x['count'],'mine':bool(x['mine'])} for x in react]}
    def do_POST(self):
        p=self.route()
        try: d=self.body()
        except Exception as e: return self.send_json({'error':str(e) or 'Некоректний запит.'},400)
        if p=='/api/register':
            if self.rate_limited('register',10,3600):return self.send_json({'error':'Забагато спроб створити акаунт. Спробуй пізніше.'},429)
            handle=str(d.get('handle','')).strip(); password=str(d.get('password',''))
            if not HANDLE.fullmatch(handle): return self.send_json({'error':'Позивний: латиниця, цифри й підкреслення; 3–21 символ.'},400)
            compact=handle.lower().replace('_','')
            if any(compact.startswith(name.replace('_','')) for name in RESERVED): return self.send_json({'error':'Цей позивний зарезервовано.'},400)
            if len(password)<10 or len(password)>128 or not re.search('[A-Za-z]',password) or not re.search('[0-9]',password): return self.send_json({'error':'Пароль має містити 10–128 символів, літеру й цифру.'},400)
            if password.casefold()==handle.casefold(): return self.send_json({'error':'Пароль не може збігатися з позивним.'},400)
            uid=secrets.token_urlsafe(18); token=secrets.token_urlsafe(32); salt,ph=password_hash(password); ts=now()
            try:
                with db() as c:
                    c.execute('INSERT INTO users VALUES(?,?,?,?,?)',(uid,handle,salt,ph,ts)); c.execute('INSERT INTO prefs(user_id) VALUES(?)',(uid,)); chat=secrets.token_urlsafe(12); c.execute("INSERT INTO chats(id,kind,created,wallpaper) VALUES(?,'notes',?,'carbon')",(chat,ts)); c.execute('INSERT INTO members VALUES(?,?)',(chat,uid)); c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),uid,ts+30*86400))
            except sqlite3.IntegrityError: return self.send_json({'error':'Позивний уже зайнятий.'},409)
            return self.send_json({'user':{'id':uid,'handle':handle},'chats':[{'id':chat,'kind':'notes','title':'NOTES','lastAt':ts,'wallpaper':'carbon'}],'selected':chat,'prefs':{'preset':'REDLINE','wallpaper':'carbon','reducedMotion':False}},201,{'Set-Cookie':self.session_cookie(token,2592000)})
        if p=='/api/login':
            if self.rate_limited('login',12,600):return self.send_json({'error':'Забагато спроб входу. Зачекай трохи.'},429)
            identifier=str(d.get('identifier','')).strip(); password=str(d.get('password',''))
            with db() as c:
                row=c.execute('SELECT * FROM users WHERE handle=? COLLATE NOCASE',(identifier,)).fetchone()
                valid=bool(row and hmac.compare_digest(password_hash(password,row['salt'])[1],row['password_hash']))
                if not valid: return self.send_json({'error':'Позивний або пароль неправильний.'},401)
                token=secrets.token_urlsafe(32); c.execute('INSERT INTO sessions VALUES(?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),row['id'],now()+30*86400))
            return self.send_json({'ok':True},200,{'Set-Cookie':self.session_cookie(token,2592000)})
        a=self.need()
        if not a: return
        uid=a[0]['id']
        if p=='/api/logout':
            with db() as c:c.execute('DELETE FROM sessions WHERE token_hash=?',(a[0]['token_hash'],))
            return self.send_json({'ok':True},200,{'Set-Cookie':self.session_cookie('',0)})
        if p=='/api/chats':
            peer=str(d.get('userId','')); key=':'.join(sorted([uid,peer]))
            if not peer or peer==uid:return self.send_json({'error':'Обери інший позивний.'},400)
            with db() as c:
                if not c.execute('SELECT 1 FROM users WHERE id=?',(peer,)).fetchone(): return self.send_json({'error':'Позивний не знайдено.'},404)
                row=c.execute('SELECT id FROM chats WHERE pair_key=?',(key,)).fetchone()
                if row: return self.send_json({'id':row['id']})
                cid=secrets.token_urlsafe(12); ts=now(); inherited=c.execute('SELECT wallpaper FROM prefs WHERE user_id=?',(uid,)).fetchone()['wallpaper']; c.execute("INSERT OR IGNORE INTO chats(id,kind,pair_key,created,wallpaper) VALUES(?,'dm',?,?,?)",(cid,key,ts,inherited)); row=c.execute('SELECT id FROM chats WHERE pair_key=?',(key,)).fetchone(); cid=row['id']
                c.execute('INSERT OR IGNORE INTO members VALUES(?,?)',(cid,uid)); c.execute('INSERT OR IGNORE INTO members VALUES(?,?)',(cid,peer)); return self.send_json({'id':cid})
        m=re.fullmatch(r'/api/chats/([\w-]+)/messages',p)
        if m:
            chat=m.group(1); text=str(d.get('text','')); client=str(d.get('clientId','')); reply=d.get('replyToId')
            if not text.strip() or len(text)>2000 or not re.fullmatch(r'[A-Za-z0-9_-]{8,80}',client):return self.send_json({'error':'Перевір текст повідомлення.'},400)
            with db() as c:
                if not c.execute('SELECT 1 FROM members WHERE chat_id=? AND user_id=?',(chat,uid)).fetchone():return self.send_json({'error':'Чат недоступний.'},404)
                if reply and not c.execute('SELECT 1 FROM messages WHERE id=? AND chat_id=?',(reply,chat)).fetchone():return self.send_json({'error':'Повідомлення для відповіді не знайдено.'},400)
                mid=secrets.token_urlsafe(12); ts=now(); c.execute('INSERT OR IGNORE INTO messages(id,chat_id,client_id,author_id,text,created,reply_id) VALUES(?,?,?,?,?,?,?)',(mid,chat,client,uid,text,ts,reply)); row=c.execute('SELECT * FROM messages WHERE chat_id=? AND client_id=?',(chat,client)).fetchone(); return self.send_json({'message':self.message(c,row,uid)})
        m=re.fullmatch(r'/api/messages/([\w-]+)/(reaction|edit|delete)',p)
        if m:
            mid,action=m.groups()
            with db() as c:
                row=c.execute('SELECT * FROM messages WHERE id=?',(mid,)).fetchone()
                if not row or not c.execute('SELECT 1 FROM members WHERE chat_id=? AND user_id=?',(row['chat_id'],uid)).fetchone():return self.send_json({'error':'Повідомлення не знайдено.'},404)
                if action=='reaction':
                    emoji=str(d.get('emoji',''))
                    if emoji not in ['❤️','👍','😂','🔥','👀','✨','😮','🎯']:return self.send_json({'error':'Невідома реакція.'},400)
                    c.execute('DELETE FROM reactions WHERE message_id=? AND user_id=? AND emoji=?',(mid,uid,emoji)) if c.execute('SELECT 1 FROM reactions WHERE message_id=? AND user_id=? AND emoji=?',(mid,uid,emoji)).fetchone() else c.execute('INSERT INTO reactions VALUES(?,?,?)',(mid,uid,emoji))
                    row=c.execute('SELECT * FROM messages WHERE id=?',(mid,)).fetchone(); return self.send_json({'message':self.message(c,row,uid)})
                if row['author_id']!=uid:return self.send_json({'error':'Змінювати можна лише власні повідомлення.'},403)
                if action=='delete':c.execute('DELETE FROM messages WHERE id=?',(mid,));return self.send_json({'ok':True})
                text=str(d.get('text',''))
                if not text.strip() or len(text)>2000:return self.send_json({'error':'Текст має містити 1–2000 символів.'},400)
                c.execute('UPDATE messages SET text=?,edited=? WHERE id=?',(text,now(),mid)); row=c.execute('SELECT * FROM messages WHERE id=?',(mid,)).fetchone();return self.send_json({'message':self.message(c,row,uid)})
        if p=='/api/prefs':
            preset=d.get('preset'); wallpaper=d.get('wallpaper'); reduced=bool(d.get('reducedMotion',False))
            if preset not in ['REDLINE','PHOSPHOR','PAPER'] or wallpaper not in ['carbon','noise','geometry','scan','ink','fabric']:return self.send_json({'error':'Невідомий вигляд.'},400)
            with db() as c:c.execute('UPDATE prefs SET preset=?,wallpaper=?,reduced=? WHERE user_id=?',(preset,wallpaper,int(reduced),uid))
            return self.send_json({'ok':True})
        m=re.fullmatch(r'/api/chats/([\w-]+)/draft',p)
        if m:
            text=str(d.get('text',''))
            if len(text)>2000:return self.send_json({'error':'Чернетка завелика.'},400)
            with db() as c:
                if not c.execute('SELECT 1 FROM members WHERE chat_id=? AND user_id=?',(m.group(1),uid)).fetchone():return self.send_json({'error':'Чат недоступний.'},404)
                if text:c.execute('INSERT INTO drafts VALUES(?,?,?,?) ON CONFLICT(user_id,chat_id) DO UPDATE SET text=excluded.text,changed=excluded.changed',(uid,m.group(1),text,now()))
                else:c.execute('DELETE FROM drafts WHERE user_id=? AND chat_id=?',(uid,m.group(1)))
            return self.send_json({'ok':True})
        m=re.fullmatch(r'/api/chats/([\w-]+)/wallpaper',p)
        if m:
            wallpaper=str(d.get('wallpaper',''))
            if wallpaper not in ['carbon','noise','geometry','scan','ink','fabric']:return self.send_json({'error':'Невідома шпалера.'},400)
            with db() as c:
                if not c.execute('SELECT 1 FROM members WHERE chat_id=? AND user_id=?',(m.group(1),uid)).fetchone():return self.send_json({'error':'Чат недоступний.'},404)
                c.execute('UPDATE chats SET wallpaper=? WHERE id=?',(wallpaper,m.group(1)))
            return self.send_json({'ok':True})
        return self.send_json({'error':'Не знайдено.'},404)

if __name__=='__main__':
    host=os.environ.get('REDLINE_HOST','127.0.0.1'); port=int(os.environ.get('PORT','8787'))
    print(f'REDLINE listening at http://{host}:{port}; database: {DB}')
    ThreadingHTTPServer((host,port),Handler).serve_forever()
